const donasi = () => {
	return `👾JEJAK INTERNET👾	

  Hi👋️
  
          *FITUR*
          
┏━━━°❀ ❬ 𝘼𝘽𝙊𝙐𝙏 ❭ ❀°━━━┓
┃
┏❉ *#info*
┣❉ *#Donasi* 
┗❉ *#creator* 
┃
┣━━━°❀ ❬ 𝗗𝗢𝗡𝗔𝗦𝗜 ❭ ❀°━━━⊱
┃
┣➥ *GOPAY:* 089614913822
┣➥ *PULSA:* 081882858970
┣➥ *KUOTA:* 081882858970
┃
┣━━━━━━━━━━━━━━━━━━━━
┃
┣━━━━━━━━━━━━━━━━━━━━
┃*POWERED BY JEJAK INTERNET*
┗━━━━━━━━━━━━━━━━━━━━`
}

exports.donasi = donasi
